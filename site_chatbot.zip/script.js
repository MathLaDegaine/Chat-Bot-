document.addEventListener("DOMContentLoaded", function() {
    Vue.component('accueil', {
        template: '<div><h2>Bienvenue</h2><p>Bienvenue sur la plateforme d\'exercices scolaires.</p></div>'
    });
    Vue.component('maths', {
        template: '<div><h2>Mathématiques</h2><p>Exercices de mathématiques ici.</p></div>'
    });
    Vue.component('francais', {
        template: '<div><h2>Français</h2><p>Exercices de français ici.</p></div>'
    });
    Vue.component('histoiregeo', {
        template: '<div><h2>Histoire-Géo</h2><p>Exercices d\'histoire-géo ici.</p></div>'
    });
    Vue.component('anglais', {
        template: '<div><h2>Anglais</h2><p>Exercices d\'anglais ici.</p></div>'
    });
    Vue.component('science', {
        template: '<div><h2>Science</h2><p>Exercices de sciences ici.</p></div>'
    });
    Vue.component('profil', {
        template: '<div><h2>Profil</h2><p>Informations sur le profil.</p></div>'
    });

    new Vue({
        el: "#app",
        data: {
            pages: [
                { name: "Mathématiques", component: "maths" },
                { name: "Français", component: "francais" },
                { name: "Histoire-Géo", component: "histoiregeo" },
                { name: "Anglais", component: "anglais" },
                { name: "Science", component: "science" },
                { name: "Profil", component: "profil" }
            ],
            currentPage: "Accueil",
            hoverMenu: "",
            chatOpen: false,
            chatInput: "",
            chatMessages: []
        },
        computed: {
            currentComponent() {
                return this.currentPage === "Accueil" ? "accueil" : this.pages.find(page => page.name === this.currentPage).component;
            }
        },
        methods: {
            changePage(page) {
                this.currentPage = page.name;
            },
            changePageAccueil() {
                this.currentPage = "Accueil";
            },
            toggleChat() {
                this.chatOpen = !this.chatOpen;
            },
            sendMessage() {
                if (this.chatInput.trim() === "") return;

                // Ajouter le message de l'utilisateur à la conversation
                this.chatMessages.push({ text: this.chatInput, type: "user" });
                this.chatInput = "";

                // Envoyer la requête à l'API OpenAI pour obtenir la réponse du chatbot
                fetch('http://localhost:3000/ask', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ message: this.chatMessages[this.chatMessages.length - 1].text })
                })
                .then(response => response.json())
                .then(data => {
                    // Ajouter la réponse du chatbot à la conversation
                    this.chatMessages.push({ text: data.reply, type: "bot" });
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    this.chatMessages.push({ text: "Désolé, une erreur est survenue.", type: "bot" });
                });
            }
        }
    });
}); 